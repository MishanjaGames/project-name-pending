import React, { useState, useContext } from 'react';
import { useNavigate } from 'react-router-dom';
import { SettingsContext } from '../contexts/SettingsContext';
import { getUser } from '../utils/auth';

export default function AddCourseForm() {
    const { t } = useContext(SettingsContext);
    const navigate = useNavigate();
    
    // Получаем текущего авторизованного пользователя
    const currentUser = getUser();
    
    const [saving, setSaving] = useState(false);
    const [skillInput, setSkillInput] = useState('');
    const [errors, setErrors] = useState({});

    // Состояние формы с дефолтными значениями и АВТОМАТИЧЕСКОЙ подстановкой ID
    const [formData, setFormData] = useState({
        userId: currentUser?.id || currentUser?._id || '', 
        status: 'editing',
        title: '',
        description: '',
        skills: [],
        direction: 'Programming', // Дефолтное значение
        level: 'Junior',          // Дефолтное значение
        price: ''
    });

    // Состояния файлов
    const [thumbnailFile, setThumbnailFile] = useState(null);
    const [thumbnailPreview, setThumbnailPreview] = useState(null);
    const [contentFiles, setContentFiles] = useState([]);

    // Нам больше не нужен useEffect с fetch, мы используем захардкоженные списки

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({ ...prev, [name]: value }));
        if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
    };

    const handleThumbnailChange = (e) => {
        const file = e.target.files[0];
        if (file) {
            if (!file.type.startsWith('image/')) {
                setErrors(prev => ({ ...prev, thumbnail: 'Please select an image file' }));
                return;
            }
            if (file.size > 5 * 1024 * 1024) {
                setErrors(prev => ({ ...prev, thumbnail: 'Image must be less than 5MB' }));
                return;
            }
            setThumbnailFile(file);
            setThumbnailPreview(URL.createObjectURL(file));
            setErrors(prev => ({ ...prev, thumbnail: '' }));
        }
    };

    const handleContentFilesChange = (e) => {
        const files = Array.from(e.target.files);
        const validFiles = [];
        for (const file of files) {
            if (file.size > 50 * 1024 * 1024) {
                alert(`File ${file.name} is too large. Maximum size is 50MB.`);
                continue;
            }
            validFiles.push(file);
        }
        setContentFiles(prev => [...prev, ...validFiles]);
    };

    const removeContentFile = (index) => {
        setContentFiles(prev => prev.filter((_, i) => i !== index));
    };

    const renameFile = (file, newName) => {
        const blob = file.slice(0, file.size, file.type);
        return new File([blob], newName, { type: file.type });
    };

    const handleAddSkill = () => {
        const trimmedSkill = skillInput.trim();
        if (trimmedSkill && !formData.skills.includes(trimmedSkill)) {
            setFormData(prev => ({ ...prev, skills: [...prev.skills, trimmedSkill] }));
            setSkillInput('');
        }
    };

    const handleRemoveSkill = (skillToRemove) => {
        setFormData(prev => ({ ...prev, skills: prev.skills.filter(skill => skill !== skillToRemove) }));
    };

    const handleSkillInputKeyPress = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            handleAddSkill();
        }
    };

    const validateForm = () => {
        const newErrors = {};
        if (!formData.userId) newErrors.userId = 'Owner ID is missing. Please re-login.';
        if (!formData.title.trim()) newErrors.title = 'Title is required';
        if (formData.price && isNaN(parseFloat(formData.price))) newErrors.price = 'Price must be a valid number';

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        if (!validateForm()) return;
        setSaving(true);

        try {
            const token = localStorage.getItem('token');
            const authHeader = `Bearer ${token}`; 

            // ЭТАП 1: Создаем курс
            const response = await fetch('http://localhost:4040/api/manage/courses', {
                method: 'POST',
                headers: {
                    'Authorization': authHeader,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    userId: formData.userId,
                    status: formData.status,
                    title: formData.title,
                    description: formData.description,
                    skills: formData.skills,
                    direction: formData.direction,
                    level: formData.level,
                    price: formData.price ? parseFloat(formData.price) : 0
                })
            });

            if (!response.ok) {
                const errorData = await response.json();
                alert(`Failed to create course: ${errorData.message || 'Unknown error'}`);
                setSaving(false);
                return;
            }

            const { data: courseData } = await response.json();
            const courseId = courseData._id || courseData.id; 

            // ЭТАП 2: Загружаем обложку
            if (thumbnailFile && courseId) {
                const fileExtension = thumbnailFile.name.split('.').pop();
                const renamedFile = renameFile(thumbnailFile, `thumbnail.${fileExtension}`);
                const thumbnailFormData = new FormData();
                thumbnailFormData.append('file', renamedFile);

                await fetch(`http://localhost:4040/api/manage/courses/${courseId}/files`, {
                    method: 'POST',
                    headers: { 'Authorization': authHeader },
                    body: thumbnailFormData
                });
            }

            // ЭТАП 3: Загружаем материалы
            if (contentFiles.length > 0 && courseId) {
                const contentFormData = new FormData();
                contentFiles.forEach(file => {
                    contentFormData.append('files', file);
                });

                await fetch(`http://localhost:4040/api/manage/courses/${courseId}/files/multiple`, {
                    method: 'POST',
                    headers: { 'Authorization': authHeader },
                    body: contentFormData
                });
            }

            alert('Course created successfully!');
            navigate('/account'); 
        } catch (error) {
            console.error('Error creating course:', error);
            alert('Error creating course. Please try again.');
        } finally {
            setSaving(false);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            {/* Обложка курса */}
            <div className="text-center mb-4">
                {thumbnailPreview ? (
                    <img
                        src={thumbnailPreview}
                        alt="Thumbnail preview"
                        className="rounded mb-3 shadow-sm"
                        style={{ width: '200px', height: '120px', objectFit: 'cover' }}
                    />
                ) : (
                    <div className="rounded bg-primary bg-opacity-10 d-flex align-items-center justify-content-center text-primary mx-auto mb-3"
                        style={{ width: '200px', height: '120px' }}>
                        <i className="bi bi-image fs-1"></i>
                    </div>
                )}

                <div className="mb-2 d-flex justify-content-center gap-2">
                    <input
                        type="file" id="thumbnail" className="d-none" accept="image/*"
                        onChange={handleThumbnailChange}
                    />

                    {!thumbnailPreview ? (
                        <label htmlFor="thumbnail" className="btn btn-sm btn-primary">
                            <i className="bi bi-upload me-2"></i> {t('addCourseForm.uploadCover')}
                        </label>
                    ) : (
                        <>
                            <label htmlFor="thumbnail" className="btn btn-sm btn-warning">
                                <i className="bi bi-pencil me-1"></i> {t('addCourseForm.changeCover')}
                            </label>
                            <button
                                type="button" className="btn btn-sm btn-danger"
                                onClick={() => { setThumbnailFile(null); setThumbnailPreview(null); }}
                            >
                                <i className="bi bi-trash me-1"></i> {t('addCourseForm.removeCover')}
                            </button>
                        </>
                    )}
                </div>
                {errors.thumbnail && <small className="text-danger d-block">{errors.thumbnail}</small>}
            </div>

            <div className="row g-3">
                {/* Владелец курса (Скрыт для пользователя, так как берется из профиля) */}
                {errors.userId && <div className="col-12 text-danger fw-bold">{errors.userId}</div>}

                {/* Название */}
                <div className="col-12">
                    <label className="form-label fw-semibold">{t('addCourseForm.courseTitle')} <span className="text-danger">*</span></label>
                    <input
                        type="text" className={`form-control ${errors.title ? 'is-invalid' : ''}`}
                        name="title" value={formData.title} onChange={handleChange}
                    />
                    {errors.title && <div className="invalid-feedback">{errors.title}</div>}
                </div>

                {/* Описание */}
                <div className="col-12">
                    <label className="form-label fw-semibold">{t('addCourseForm.description')}</label>
                    <textarea
                        className="form-control" name="description"
                        value={formData.description} onChange={handleChange} rows="4"
                    />
                </div>

                {/* Направление */}
                <div className="col-12 col-md-4">
                    <label className="form-label fw-semibold">{t('addCourseForm.direction')} <span className="text-danger">*</span></label>
                    <select
                        className="form-select" name="direction" 
                        value={formData.direction} onChange={handleChange}
                    >
                        <option value="Programming">Programming</option>
                        <option value="Game Dev">Game Dev</option>
                        <option value="Data Science">Data Science</option>
                        <option value="Design">Design</option>
                    </select>
                </div>

                {/* Уровень (Теперь с Guru!) */}
                <div className="col-12 col-md-4">
                    <label className="form-label fw-semibold">{t('addCourseForm.level')} <span className="text-danger">*</span></label>
                    <select
                        className="form-select" name="level" 
                        value={formData.level} onChange={handleChange}
                    >
                        <option value="Junior">Junior</option>
                        <option value="Middle">Middle</option>
                        <option value="Senior">Senior</option>
                        <option value="Guru">Guru 🚀</option>
                    </select>
                </div>

                {/* Цена */}
                <div className="col-12 col-md-4">
                    <label className="form-label fw-semibold">{t('addCourseForm.price')} (USD)</label>
                    <div className="input-group">
                        <span className="input-group-text">$</span>
                        <input
                            type="number" className={`form-control ${errors.price ? 'is-invalid' : ''}`}
                            name="price" value={formData.price} onChange={handleChange} min="0"
                        />
                    </div>
                </div>

                {/* Skills (Чему вы научитесь) */}
                <div className="col-12">
                    <label className="form-label fw-semibold">{t('addCourseForm.skills')}</label>
                    <div className="input-group mb-2">
                        <input
                            type="text" className="form-control" value={skillInput}
                            onChange={(e) => setSkillInput(e.target.value)} onKeyPress={handleSkillInputKeyPress}
                            placeholder={t('addCourseForm.skillsPlaceholder')}
                        />
                        <button className="btn btn-outline-primary" type="button" onClick={handleAddSkill}>
                            <i className="bi bi-plus-lg"></i>
                        </button>
                    </div>
                    {formData.skills.length > 0 && (
                        <div className="d-flex flex-wrap gap-2">
                            {formData.skills.map((skill, idx) => (
                                <span key={idx} className="badge bg-primary d-flex align-items-center p-2">
                                    {skill}
                                    <i className="bi bi-x-lg ms-2" style={{ cursor: 'pointer' }} onClick={() => handleRemoveSkill(skill)}></i>
                                </span>
                            ))}
                        </div>
                    )}
                </div>

                {/* Файлы / Видео */}
                <div className="col-12 mt-4">
                    <label className="form-label fw-semibold">{t('addCourseForm.courseMaterials')}</label>
                    <div className="border rounded p-3 bg-light">
                        <input
                            type="file" id="contentFiles" className="d-none" multiple
                            onChange={handleContentFilesChange}
                        />
                        <label htmlFor="contentFiles" className="btn btn-outline-primary mb-3">
                            <i className="bi bi-upload me-2"></i> {t('addCourseForm.uploadMaterials')}
                        </label>

                        {contentFiles.length > 0 && (
                            <ul className="list-group">
                                {contentFiles.map((file, idx) => (
                                    <li key={idx} className="list-group-item d-flex justify-content-between align-items-center">
                                        <span className="text-truncate" style={{maxWidth: '80%'}}>{file.name}</span>
                                        <button type="button" className="btn btn-sm btn-outline-danger" onClick={() => removeContentFile(idx)}>
                                            <i className="bi bi-x-lg"></i>
                                        </button>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </div>
                </div>
            </div>

            <div className="d-flex justify-content-end gap-2 mt-4 pt-3 border-top">
                <button type="button" className="btn btn-outline-secondary" onClick={() => navigate(-1)} disabled={saving}>{t('addCourseForm.cancel')}</button>
                <button type="submit" className="btn btn-success" disabled={saving}>
                    {saving ? (
                        <><span className="spinner-border spinner-border-sm me-2" aria-hidden="true"></span>{t('addCourseForm.saving')}...</>
                    ) : t('addCourseForm.createCourse')}
                </button>
            </div>
        </form>
    );
}