import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { Navbar } from "../components/Navbar";
import AuthImage from "../components/AuthImage";
import { UtilityModal } from '../components/UtilityModal';

const LANG_LABELS = { en: "English", ua: "Ukrainian" };
const ALL_LANGS   = ["en", "ua"];
const emptyTrans  = () => ({ title: "", description: "", skills: [] });

function EditCourse({ data, onLogout }) {
    const { id } = useParams();
    const navigate = useNavigate();
    const token = localStorage.getItem("token");
    const ah = token ? { Authorization: `${token.split(" ")[0]} ${token.split(" ")[1]}`, "Content-Type": "application/json" } : {};
    const mh = token ? { Authorization: `${token.split(" ")[0]} ${token.split(" ")[1]}` } : {};

    const [loading, setLoading]         = useState(true);
    const [saving, setSaving]           = useState(false);
    const [users, setUsers]             = useState([]);
    const [directions, setDirections]   = useState([]);
    const [levels, setLevels]           = useState([]);

    // Lang state
    const [baseLang, setBaseLang]       = useState("en");
    const [addLangs, setAddLangs]       = useState([]);
    const [trans, setTrans]             = useState([emptyTrans()]);
    const [activeLang, setActiveLang]   = useState(0);
    const [skillInputs, setSkillInputs] = useState([""]);

    const [formData, setFormData] = useState({ userId: "", status: "", direction: "", level: "", price: "", courseType: "SELF_TAUGHT", links: [] });
    const [errors, setErrors]     = useState({});

    // File states
    const [thumbnail, setThumbnail]               = useState(null);
    const [thumbnailPreview, setThumbnailPreview] = useState(null);
    const [courseFiles, setCourseFiles]           = useState([]);
    const [existingFiles, setExistingFiles]       = useState([]);
    // File filter/sort for existingFiles
    const [fileSearch, setFileSearch]   = useState('');
    const [fileTypeFilter, setFileTypeFilter] = useState('all');
    const [fileSortBy, setFileSortBy]   = useState('name'); // 'name' | 'date' | 'type' | 'size'
    // ── Modal state ──────────────────────────────────────────────────────────
    const [modal, setModal] = useState({ show: false, type: 'info', title: '', message: '', confirmToken: '', tokenLabel: '', onConfirm: null, onDelete: null, onCancel: null, onClose: null, danger: false });
    const closeModal  = () => setModal(p => ({ ...p, show: false }));
    const showInfo    = (title, message) => setModal({ show: true, type: 'info', title, message, onClose: closeModal });
    const showConfirm = (title, message, onConfirm, danger = false) => setModal({ show: true, type: 'confirm', danger, title, message, onConfirm, onCancel: closeModal });
    const showDelete  = (title, message, confirmToken, tokenLabel, onDelete) => setModal({ show: true, type: 'delete', title, message, confirmToken, tokenLabel, onDelete, onCancel: closeModal, deleteLabel: 'Delete' });

    // Move an item in a list up (-1) or down (+1)
    const moveItem = (setter, idx, dir) => {
        setter(prev => {
            const arr = [...prev];
            const target = idx + dir;
            if (target < 0 || target >= arr.length) return arr;
            [arr[idx], arr[target]] = [arr[target], arr[idx]];
            return arr;
        });
    };

    const isSystemTextFile = (fn) => /^vol-\d+-ch-\d+-item-\d+-\d+\.txt$/i.test(fn);

    useEffect(() => {
        if (!token) return;
        const fetchAll = async () => {
            try {
                const [courseRes, usersRes, dirsRes, lvlsRes, filesRes] = await Promise.all([
                    fetch(`http://localhost:4040/api/manage/courses/${id}`, { headers: ah }),
                    fetch("http://localhost:4040/api/manage/users", { headers: ah }),
                    fetch("http://localhost:4040/api/directions", { headers: ah }),
                    fetch("http://localhost:4040/api/levels", { headers: ah }),
                    fetch(`http://localhost:4040/api/manage/courses/${id}/files`, { headers: ah })
                ]);

                if (!courseRes.ok) { showInfo('Error', 'Failed to fetch course details'); navigate("/manage/courses"); return; }
                const { data: course } = await courseRes.json();

                setBaseLang(course.base_lang || "en");
                const al = Array.isArray(course.add_langs) ? course.add_langs : [];
                setAddLangs(al);

                const langs = [course.base_lang || "en", ...al];
                const loadedTrans = Array.isArray(course.trans) && course.trans.length > 0
                    ? langs.map((_, i) => ({
                        title:       course.trans[i]?.title       || "",
                        description: course.trans[i]?.description || "",
                        skills:      Array.isArray(course.trans[i]?.skills) ? course.trans[i].skills : []
                      }))
                    : langs.map(() => emptyTrans());
                setTrans(loadedTrans);
                setSkillInputs(langs.map(() => ""));

                setFormData({
                    userId:     course.userId     || "",
                    status:     course.status     || "editing",
                    direction:  course.direction  || "",
                    level:      course.level      || "",
                    courseType: course.courseType || "SELF_TAUGHT",
                    price:      course.price?.toString() || "",
                    links:      course.links      || []
                });

                if (usersRes.ok) { const d = await usersRes.json(); setUsers(d.data || d); }
                if (dirsRes.ok)  { const d = await dirsRes.json();  setDirections(d.data || []); }
                if (lvlsRes.ok)  { const d = await lvlsRes.json();  setLevels(d.data || []); }

                if (filesRes.ok) {
                    const d = await filesRes.json();
                    const all = d.data || d.files || [];
                    setExistingFiles(all.filter(f => {
                        const fn = (f.originalName || f.filename || "").toLowerCase();
                        return !fn.includes("thumbnail") && !isSystemTextFile(f.originalName || f.filename || "");
                    }));
                }
            } catch (err) {
                console.error(err); showInfo('Error', 'Error loading course details'); navigate("/manage/courses");
            } finally { setLoading(false); }
        };
        fetchAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [id]);

    const allLangs = [baseLang, ...addLangs];

    const toggleAddLang = (lang) => {
        if (addLangs.includes(lang)) {
            const idx = addLangs.indexOf(lang);
            setAddLangs(p => p.filter(l => l !== lang));
            setTrans(p => p.filter((_, i) => i !== idx + 1));
            setSkillInputs(p => p.filter((_, i) => i !== idx + 1));
            if (activeLang > trans.length - 2) setActiveLang(0);
        } else {
            setAddLangs(p => [...p, lang]);
            setTrans(p => [...p, emptyTrans()]);
            setSkillInputs(p => [...p, ""]);
        }
    };

    const handleTransChange = (idx, field, value) =>
        setTrans(p => p.map((t, i) => i === idx ? { ...t, [field]: value } : t));

    const handleAddSkill = (idx) => {
        const trimmed = skillInputs[idx]?.trim();
        if (!trimmed || trans[idx]?.skills.includes(trimmed)) return;
        setTrans(p => p.map((t, i) => i === idx ? { ...t, skills: [...t.skills, trimmed] } : t));
        setSkillInputs(p => p.map((s, i) => i === idx ? "" : s));
    };
    const handleRemoveSkill = (ti, skill) =>
        setTrans(p => p.map((t, i) => i === ti ? { ...t, skills: t.skills.filter(s => s !== skill) } : t));

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData(p => ({ ...p, [name]: value }));
        if (errors[name]) setErrors(p => ({ ...p, [name]: "" }));
    };

    const handleThumbnailChange = (e) => {
        const file = e.target.files[0];
        if (!file) return;
        if (!file.type.startsWith("image/")) { setErrors(p => ({ ...p, thumbnail: "Please select an image file" })); return; }
        if (file.size > 5 * 1024 * 1024) { setErrors(p => ({ ...p, thumbnail: "Thumbnail must be less than 5MB" })); return; }
        setThumbnail(file);
        setThumbnailPreview(URL.createObjectURL(file));
        setErrors(p => ({ ...p, thumbnail: "" }));
    };

    const deleteExistingFile = async (idx) => {
        const file = existingFiles[idx];
        showConfirm('Delete File', `Delete "${file.originalName || file.filename}"?`, async () => {
            try {
                const res = await fetch(`http://localhost:4040/api/manage/courses/${id}/files/${file.filename || file.originalName}`, { method: "DELETE", headers: ah });
                if (res.ok) { setExistingFiles(p => p.filter((_, i) => i !== idx)); showInfo('Deleted', 'File deleted successfully.'); }
                else showInfo('Error', 'Failed to delete file.');
            } catch (err) { console.error(err); showInfo('Error', 'Error deleting file.'); }
        }, true);
    };

    const validateForm = () => {
        const e = {};
        if (!formData.userId)           e.userId    = "Owner is required";
        if (!formData.status)           e.status    = "Status is required";
        if (!formData.direction.trim()) e.direction = "Direction is required";
        if (!formData.level.trim())     e.level     = "Level is required";
        if (!trans[0]?.title?.trim())   e.baseTitle = `Title is required for ${LANG_LABELS[baseLang]}`;
        if (formData.price && isNaN(parseFloat(formData.price))) e.price = "Price must be a valid number";
        setErrors(e);
        return Object.keys(e).length === 0;
    };

    const handleSubmit = async (ev) => {
        ev.preventDefault();
        if (!validateForm()) return;
        setSaving(true);
        try {
            // Rebuild links: thumbnail first (from formData.links), then existingFiles in sorted order
            const thumbnailLinks = (formData.links || []).filter(l =>
                l.description && l.description.toLowerCase() === "course thumbnail"
            );
            const reorderedFileLinks = existingFiles
                .filter(f => f.url || f.path)
                .map(f => ({
                    type:        f.type || "other",
                    url:         f.url  || f.path,
                    filename:    f.filename    || f.originalName || "",
                    accessLevel: f.accessLevel || "default",
                    description: f.originalName || f.filename || ""
                }));
            const mergedLinks = [...thumbnailLinks, ...reorderedFileLinks];

            const res = await fetch(`http://localhost:4040/api/manage/courses/${id}`, {
                method: "PATCH", headers: ah,
                body: JSON.stringify({
                    userId: formData.userId, status: formData.status,
                    base_lang: baseLang, add_langs: addLangs, trans,
                    direction: formData.direction, level: formData.level,
                    courseType: formData.courseType || "SELF_TAUGHT",
                    price: formData.price ? parseFloat(formData.price) : 0,
                    links: mergedLinks
                })
            });
            if (!res.ok) { const err = await res.json(); showInfo('Error', `Failed to update: ${err.message || "Unknown error"}`); setSaving(false); return; }

            if (thumbnail) {
                const fd = new FormData(); fd.append("file", thumbnail);
                await fetch(`http://localhost:4040/api/manage/courses/${id}/files?thumbnail=true`, { method: "POST", headers: mh, body: fd });
            }

            if (courseFiles.length > 0) {
                const fd = new FormData(); courseFiles.forEach(f => fd.append("files", f));
                const fr = await fetch(`http://localhost:4040/api/manage/courses/${id}/files/multiple`, { method: "POST", headers: mh, body: fd });
                if (!fr.ok) { const err = await fr.json(); showInfo('Error', `File upload failed: ${err.message || "Unknown error"}`); }
                else {
                    // Refresh existing files list
                    const refreshRes = await fetch(`http://localhost:4040/api/manage/courses/${id}/files`, { headers: ah });
                    if (refreshRes.ok) {
                        const d = await refreshRes.json();
                        const all = d.data || d.files || [];
                        setExistingFiles(all.filter(f => {
                            const fn = (f.originalName || f.filename || "").toLowerCase();
                            return !fn.includes("thumbnail") && !isSystemTextFile(f.originalName || f.filename || "");
                        }));
                    }
                }
            }

            showInfo('Success', 'Course updated successfully!');
            setThumbnail(null); setThumbnailPreview(null); setCourseFiles([]);
            navigate("/manage/courses");
        } catch (err) { console.error(err); showInfo('Error', 'Error updating course. Please try again.'); }
        finally { setSaving(false); }
    };

    const getStatusBadge = (s) => ({ deployed: "bg-success", "on-check": "bg-warning text-dark", editing: "bg-secondary" }[s] || "bg-light text-dark");

    if (loading) return (
        <>
            <Navbar data={data} onLogout={onLogout} />
            <div className="flex-grow-1 d-flex align-items-center justify-content-center">
                <div className="text-center">
                    <div className="spinner-border text-primary mb-3" /><p className="text-muted">Loading course details...</p>
                </div>
            </div>
        </>
    );

    return (
        <>
            <Navbar data={data} onLogout={onLogout} />
            <div className="flex-grow-1 p-3 p-md-4" style={{ minWidth: 0 }}>
                <div className="row mb-4">
                    <div className="col-12">
                        <button className="btn btn-outline-secondary btn-sm mb-2" onClick={() => navigate("/manage/courses")}>← Back to Courses</button>
                        <h1 className="h3 fw-bold text-dark mb-1">Edit Course</h1>
                        <p className="text-muted mb-0 small">Update course information and settings</p>
                    </div>
                </div>
                <div className="row">
                    <div className="col-12 col-lg-10 col-xl-8">
                        <div className="card border-0 shadow-sm">
                            <div className="card-body p-4">
                                <form onSubmit={handleSubmit}>

                                    {/* Thumbnail */}
                                    <div className="text-center mb-4">
                                        <label className="form-label fw-semibold d-block mb-2">Course Thumbnail</label>
                                        {thumbnailPreview ? (
                                            <img src={thumbnailPreview} alt="Thumbnail" className="rounded mb-2" style={{ maxWidth: "100%", height: 150, objectFit: "cover" }} />
                                        ) : formData.links?.[0]?.url ? (
                                            <AuthImage src={formData.links[0].url} alt="Current thumbnail" className="rounded mb-2"
                                                style={{ maxWidth: "100%", height: 150, objectFit: "cover" }}
                                                fallback={<div className="rounded bg-primary bg-opacity-10 d-flex align-items-center justify-content-center text-primary mx-auto mb-2" style={{ width: 150, height: 150 }}><span className="text-muted small">No thumbnail</span></div>} />
                                        ) : (
                                            <div className="rounded bg-primary bg-opacity-10 d-flex align-items-center justify-content-center text-primary mx-auto mb-2" style={{ width: 150, height: 150 }}>
                                                <span className="text-muted small">No thumbnail</span>
                                            </div>
                                        )}
                                        <div className="d-flex justify-content-center gap-2 mb-1">
                                            <input type="file" id="thumbnail" className="d-none" accept="image/*" onChange={handleThumbnailChange} />
                                            {!thumbnailPreview && !formData.links?.[0]?.url ? (
                                                <label htmlFor="thumbnail" className="btn btn-sm btn-primary">Upload Thumbnail</label>
                                            ) : (
                                                <>
                                                    <label htmlFor="thumbnail" className="btn btn-sm btn-warning">Change</label>
                                                    <button type="button" className="btn btn-sm btn-danger"
                                                        onClick={() => { setThumbnail(null); setThumbnailPreview(null); setFormData(p => ({ ...p, links: [] })); }}>Delete</button>
                                                </>
                                            )}
                                        </div>
                                        {errors.thumbnail && <small className="text-danger d-block">{errors.thumbnail}</small>}
                                        {formData.status && <div className="mt-2"><span className={`badge rounded-pill ${getStatusBadge(formData.status)}`}>{formData.status}</span></div>}
                                    </div>

                                    <div className="row g-3">
                                        {/* Owner */}
                                        <div className="col-12 col-md-6">
                                            <label className="form-label fw-semibold">Course Owner <span className="text-danger">*</span></label>
                                            <select className={`form-select ${errors.userId ? "is-invalid" : ""}`} name="userId" value={formData.userId} onChange={handleChange}>
                                                <option value="">Select an owner</option>
                                                {users.map(u => <option key={u._id} value={u._id}>{u.nickname} ({u.email})</option>)}
                                            </select>
                                            {errors.userId && <div className="invalid-feedback">{errors.userId}</div>}
                                        </div>

                                        {/* Status */}
                                        <div className="col-12 col-md-6">
                                            <label className="form-label fw-semibold">Status <span className="text-danger">*</span></label>
                                            <select className={`form-select ${errors.status ? "is-invalid" : ""}`} name="status" value={formData.status} onChange={handleChange}>
                                                <option value="">Select status</option>
                                                <option value="editing">Editing</option>
                                                <option value="on-check">On Check</option>
                                                <option value="deployed">Deployed</option>
                                            </select>
                                            {errors.status && <div className="invalid-feedback">{errors.status}</div>}
                                        </div>

                                        {/* Course Type */}
                                        <div className="col-12 col-md-6">
                                            <label className="form-label fw-semibold">Course Type</label>
                                            <select className="form-select"
                                                value={formData.courseType || "SELF_TAUGHT"}
                                                onChange={e => setFormData(p => ({ ...p, courseType: e.target.value }))}>
                                                <option value="SELF_TAUGHT">Self-Taught — student buys &amp; learns independently</option>
                                                <option value="MENTORED">Mentored — student owns course, tutor guides</option>
                                                <option value="HOSTED">Hosted — tutor hosts, no purchase needed</option>
                                            </select>
                                            <small className="text-muted">Determines how students access this course</small>
                                        </div>

                                        {/* Base language */}
                                        <div className="col-12 col-md-6">
                                            <label className="form-label fw-semibold">Base Language <span className="text-danger">*</span></label>
                                            <select className="form-select" value={baseLang}
                                                onChange={e => { setBaseLang(e.target.value); setActiveLang(0); }}>
                                                {ALL_LANGS.map(l => <option key={l} value={l} disabled={addLangs.includes(l)}>{LANG_LABELS[l]}</option>)}
                                            </select>
                                        </div>

                                        {/* Additional languages */}
                                        <div className="col-12 col-md-6">
                                            <label className="form-label fw-semibold">Additional Languages</label>
                                            <div className="d-flex flex-wrap gap-3 pt-2">
                                                {ALL_LANGS.filter(l => l !== baseLang).map(lang => (
                                                    <div key={lang} className="form-check m-0">
                                                        <input className="form-check-input" type="checkbox" id={`addlang-${lang}`}
                                                            checked={addLangs.includes(lang)} onChange={() => toggleAddLang(lang)} />
                                                        <label className="form-check-label" htmlFor={`addlang-${lang}`}>{LANG_LABELS[lang]}</label>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>

                                        {/* Per-language content */}
                                        <div className="col-12">
                                            <label className="form-label fw-semibold mb-2">Course Content</label>
                                            {allLangs.length > 1 && (
                                                <ul className="nav nav-tabs mb-0">
                                                    {allLangs.map((lang, idx) => (
                                                        <li key={lang} className="nav-item">
                                                            <button type="button" className={`nav-link ${activeLang === idx ? "active" : ""}`} onClick={() => setActiveLang(idx)}>
                                                                {LANG_LABELS[lang]}
                                                                {idx === 0 && <span className="badge bg-primary ms-1" style={{ fontSize: "0.6rem" }}>base</span>}
                                                                {errors.baseTitle && idx === 0 && <span className="text-danger ms-1 fw-bold">!</span>}
                                                            </button>
                                                        </li>
                                                    ))}
                                                </ul>
                                            )}
                                            {allLangs.map((lang, idx) => (
                                                <div key={lang} className="border rounded p-3 bg-light" style={{ display: activeLang === idx ? "block" : "none" }}>
                                                    <div className="d-flex gap-2 mb-3">
                                                        <span className="badge bg-secondary">{LANG_LABELS[lang]}</span>
                                                        {idx === 0 && <span className="badge bg-primary">Base Language</span>}
                                                    </div>
                                                    <div className="mb-3">
                                                        <label className="form-label fw-semibold">Title {idx === 0 && <span className="text-danger">*</span>}</label>
                                                        <input type="text"
                                                            className={`form-control ${errors.baseTitle && idx === 0 ? "is-invalid" : ""}`}
                                                            value={trans[idx]?.title || ""}
                                                            onChange={e => handleTransChange(idx, "title", e.target.value)}
                                                            placeholder={`Course title in ${LANG_LABELS[lang]}`} />
                                                        {errors.baseTitle && idx === 0 && <div className="invalid-feedback">{errors.baseTitle}</div>}
                                                    </div>
                                                    <div className="mb-3">
                                                        <label className="form-label fw-semibold">Description</label>
                                                        <textarea className="form-control" rows="3"
                                                            value={trans[idx]?.description || ""}
                                                            onChange={e => handleTransChange(idx, "description", e.target.value)}
                                                            placeholder={`Course description in ${LANG_LABELS[lang]}`} />
                                                    </div>
                                                    <div>
                                                        <label className="form-label fw-semibold">Skills</label>
                                                        <div className="input-group mb-2">
                                                            <input type="text" className="form-control"
                                                                value={skillInputs[idx] || ""}
                                                                onChange={e => setSkillInputs(p => p.map((s, i) => i === idx ? e.target.value : s))}
                                                                onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); handleAddSkill(idx); } }}
                                                                placeholder="Type a skill and press Enter" />
                                                            <button type="button" className="btn btn-outline-primary" onClick={() => handleAddSkill(idx)}>Add</button>
                                                        </div>
                                                        {trans[idx]?.skills?.length > 0 && (
                                                            <div className="d-flex flex-wrap gap-2">
                                                                {trans[idx].skills.map((skill, si) => (
                                                                    <span key={si} className="badge bg-primary d-flex align-items-center gap-1" style={{ fontSize: "0.875rem", padding: "0.5rem 0.75rem" }}>
                                                                        {skill}
                                                                        <svg width="12" height="12" fill="currentColor" viewBox="0 0 16 16" style={{ cursor: "pointer" }} onClick={() => handleRemoveSkill(idx, skill)}>
                                                                            <path d="M2.146 2.854a.5.5 0 1 1 .708-.708L8 7.293l5.146-5.147a.5.5 0 0 1 .708.708L8.707 8l5.147 5.146a.5.5 0 0 1-.708.708L8 8.707l-5.146 5.147a.5.5 0 0 1-.708-.708L7.293 8 2.146 2.854z"/>
                                                                        </svg>
                                                                    </span>
                                                                ))}
                                                            </div>
                                                        )}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>

                                        {/* Existing files */}
                                        {existingFiles.length > 0 && (
                                            <div className="col-12">
                                                <div className="d-flex justify-content-between align-items-center mb-1">
                                                    <label className="form-label fw-semibold mb-0">Uploaded Course Files ({existingFiles.length})</label>
                                                    {/* File filters */}
                                                    {existingFiles.length > 1 && (
                                                        <div className="d-flex gap-2 flex-wrap mt-2 mb-2">
                                                            <input type="text" className="form-control form-control-sm" placeholder="Search files…"
                                                                style={{ maxWidth: 180 }} value={fileSearch}
                                                                onChange={e => setFileSearch(e.target.value)} />
                                                            <select className="form-select form-select-sm" style={{ maxWidth: 130 }}
                                                                value={fileTypeFilter} onChange={e => setFileTypeFilter(e.target.value)}>
                                                                <option value="all">All types</option>
                                                                <option value="image">Images</option>
                                                                <option value="video">Videos</option>
                                                                <option value="audio">Audio</option>
                                                                <option value="document">Documents</option>
                                                                <option value="archive">Archives</option>
                                                                <option value="other">Other</option>
                                                            </select>
                                                            <select className="form-select form-select-sm" style={{ maxWidth: 140 }}
                                                                value={fileSortBy} onChange={e => setFileSortBy(e.target.value)}>
                                                                <option value="name">Sort: Name</option>
                                                                <option value="date">Sort: Date</option>
                                                                <option value="type">Sort: Type</option>
                                                                <option value="size">Sort: Size</option>
                                                            </select>
                                                        </div>
                                                    )}
                                                    <small className="text-muted">Use ▲ ▼ to reorder · order is saved on submit</small>
                                                </div>
                                                <div className="border rounded p-2 bg-light" style={{ maxHeight: 350, overflowY: "auto" }}>
                                                    {[...existingFiles]
                                                        .filter(file => {
                                                            if (fileSearch && !file.filename?.toLowerCase().includes(fileSearch.toLowerCase()) &&
                                                                !file.url?.toLowerCase().includes(fileSearch.toLowerCase())) return false;
                                                            if (fileTypeFilter !== 'all' && (file.type || 'other') !== fileTypeFilter) return false;
                                                            return true;
                                                        })
                                                        .sort((a, b) => {
                                                            if (fileSortBy === 'name') return (a.filename || '').localeCompare(b.filename || '');
                                                            if (fileSortBy === 'type') return (a.type || '').localeCompare(b.type || '');
                                                            if (fileSortBy === 'size') return (b.size || 0) - (a.size || 0);
                                                            return 0; // date — keep original order
                                                        })
                                                        .map((file, idx) => {
                                                        const fn = file.originalName || file.filename || `File ${idx + 1}`;
                                                        const mime = file.mimetype || file.mimeType || "";
                                                        const isImg = mime.startsWith("image/"), isVid = mime.startsWith("video/"), isAud = mime.startsWith("audio/");
                                                        return (
                                                            <div key={idx} className="d-flex justify-content-between align-items-center bg-white p-2 rounded mb-2 border">
                                                                {/* Sort controls */}
                                                                <div className="d-flex flex-column me-2" style={{ gap: 1 }}>
                                                                    <button type="button" className="btn btn-sm btn-outline-secondary p-0 lh-1"
                                                                        style={{ width: 22, height: 20, fontSize: "0.65rem" }}
                                                                        disabled={idx === 0}
                                                                        onClick={() => moveItem(setExistingFiles, idx, -1)}
                                                                        title="Move up">▲</button>
                                                                    <button type="button" className="btn btn-sm btn-outline-secondary p-0 lh-1"
                                                                        style={{ width: 22, height: 20, fontSize: "0.65rem" }}
                                                                        disabled={idx === existingFiles.length - 1}
                                                                        onClick={() => moveItem(setExistingFiles, idx, 1)}
                                                                        title="Move down">▼</button>
                                                                </div>
                                                                <div className="flex-grow-1">
                                                                    <div className="small fw-semibold text-truncate" style={{ maxWidth: 400 }}>{fn}</div>
                                                                    <div className="text-muted" style={{ fontSize: "0.75rem" }}>
                                                                        <span className="badge bg-light text-dark me-1">{isImg ? "Image" : isVid ? "Video" : isAud ? "Audio" : "File"}</span>
                                                                        {file.size ? `${(file.size / 1024 / 1024).toFixed(2)} MB` : ""}
                                                                    </div>
                                                                </div>
                                                                <div className="d-flex gap-1">
                                                                    <a href={`http://localhost:4040${file.url || file.path}`} target="_blank" rel="noopener noreferrer" className="btn btn-sm btn-outline-info" title="Download">↓</a>
                                                                    <button type="button" className="btn btn-sm btn-outline-danger" onClick={() => deleteExistingFile(idx)} title="Delete">×</button>
                                                                </div>
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            </div>
                                        )}

                                        {/* Upload new files */}
                                        <div className="col-12">
                                            <label className="form-label fw-semibold">Add More Files</label>
                                            <div className="border rounded p-3 bg-light">
                                                <div className="mb-2">
                                                    <input type="file" id="courseFiles" className="d-none" multiple
                                                        onChange={e => {
                                                            const files = Array.from(e.target.files).filter(f => {
                                                                if (f.size > 512 * 1024 * 1024) { showInfo('File Too Large', `${f.name} exceeds 512 MB limit.`); return false; }
                                                                return true;
                                                            });
                                                            setCourseFiles(p => [...p, ...files]);
                                                        }}
                                                        accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.ppt,.pptx,.xlsx,.xls" />
                                                    <label htmlFor="courseFiles" className="btn btn-success btn-sm">Upload Course Files</label>
                                                </div>
                                                <small className="text-muted d-block mb-2">Max 512 MB per file.</small>
                                                {courseFiles.length > 0 && (
                                                    <>
                                                        <div className="d-flex justify-content-between align-items-center mb-2">
                                                            <strong className="small text-success">New files to upload ({courseFiles.length})</strong>
                                                            <button type="button" className="btn btn-sm btn-outline-danger" onClick={() => setCourseFiles([])}>Clear</button>
                                                        </div>
                                                        {courseFiles.map((f, i) => (
                                                            <div key={i} className="d-flex justify-content-between align-items-center bg-white p-2 rounded mb-1 border border-success">
                                                                {/* Sort controls */}
                                                                <div className="d-flex flex-column me-2" style={{ gap: 1 }}>
                                                                    <button type="button" className="btn btn-sm btn-outline-secondary p-0 lh-1"
                                                                        style={{ width: 22, height: 20, fontSize: "0.65rem" }}
                                                                        disabled={i === 0}
                                                                        onClick={() => moveItem(setCourseFiles, i, -1)}
                                                                        title="Move up">▲</button>
                                                                    <button type="button" className="btn btn-sm btn-outline-secondary p-0 lh-1"
                                                                        style={{ width: 22, height: 20, fontSize: "0.65rem" }}
                                                                        disabled={i === courseFiles.length - 1}
                                                                        onClick={() => moveItem(setCourseFiles, i, 1)}
                                                                        title="Move down">▼</button>
                                                                </div>
                                                                <span className="small fw-semibold flex-grow-1">{f.name} <span className="text-muted">({(f.size / 1024 / 1024).toFixed(2)} MB)</span></span>
                                                                <button type="button" className="btn btn-sm btn-outline-danger ms-2" onClick={() => setCourseFiles(p => p.filter((_, j) => j !== i))} title="Remove">×</button>
                                                            </div>
                                                        ))}
                                                    </>
                                                )}
                                            </div>
                                        </div>

                                        {/* Direction */}
                                        <div className="col-12 col-md-4">
                                            <label className="form-label fw-semibold">Direction <span className="text-danger">*</span></label>
                                            <select className={`form-select ${errors.direction ? "is-invalid" : ""}`} name="direction" value={formData.direction}
                                                onChange={e => { handleChange(e); setFormData(p => ({ ...p, level: "" })); }}>
                                                <option value="">Select direction</option>
                                                {directions.map(d => <option key={d._id} value={d.directionName}>{d.directionName}</option>)}
                                            </select>
                                            {errors.direction && <div className="invalid-feedback">{errors.direction}</div>}
                                        </div>

                                        {/* Level */}
                                        <div className="col-12 col-md-4">
                                            <label className="form-label fw-semibold">Level <span className="text-danger">*</span></label>
                                            <select className={`form-select ${errors.level ? "is-invalid" : ""}`} name="level" value={formData.level}
                                                onChange={handleChange} disabled={!formData.direction}>
                                                <option value="">Select level</option>
                                                {levels.filter(l => l.directionName === formData.direction).map(l => (
                                                    <option key={l._id} value={l.levelName}>{l.levelName}</option>
                                                ))}
                                            </select>
                                            {errors.level && <div className="invalid-feedback">{errors.level}</div>}
                                            {!formData.direction && <small className="text-muted">Select direction first</small>}
                                        </div>

                                        {/* Price */}
                                        <div className="col-12 col-md-4">
                                            <label className="form-label fw-semibold">Price (USD)</label>
                                            <div className="input-group">
                                                <span className="input-group-text">$</span>
                                                <input type="number" className={`form-control ${errors.price ? "is-invalid" : ""}`}
                                                    name="price" value={formData.price} onChange={handleChange}
                                                    placeholder="0.00" step="0.01" min="0" />
                                            </div>
                                            {errors.price && <div className="text-danger small mt-1">{errors.price}</div>}
                                        </div>
                                    </div>

                                    {/* Actions */}
                                    <div className="d-flex gap-2 justify-content-end pt-4 mt-3 border-top">
                                        <button type="button" className="btn btn-outline-secondary"
                                            onClick={() => showConfirm('Cancel', 'Discard unsaved changes?', () => navigate("/manage/courses"))} disabled={saving}>Cancel</button>
                                        <button type="submit" className="btn btn-primary" disabled={saving}>
                                            {saving ? <><span className="spinner-border spinner-border-sm me-2" />Saving...</> : "Save Changes"}
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <UtilityModal
                show={modal.show}
                type={modal.type}
                title={modal.title}
                message={modal.message}
                danger={modal.danger}
                confirmToken={modal.confirmToken}
                tokenLabel={modal.tokenLabel}
                deleteLabel={modal.deleteLabel || 'Delete'}
                onConfirm={() => { modal.onConfirm?.(); closeModal(); }}
                onDelete={() => { modal.onDelete?.(); closeModal(); }}
                onCancel={modal.onCancel || closeModal}
                onClose={modal.onClose || closeModal}
            />

        </>
    );
}

export default EditCourse;